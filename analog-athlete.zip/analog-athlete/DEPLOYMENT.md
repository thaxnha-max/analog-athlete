# Analog Athlete – Deployment Guide

## Overview

Analog Athlete is a Neo-Retro responsive web application built with **React 19**, **Tailwind CSS 4**, and **shadcn/ui** components. This is a **static frontend** project with no backend dependencies.

## Quick Start

### 1. Extract the Project

```bash
unzip analog-athlete-source.zip
cd analog-athlete
```

### 2. Install Dependencies

```bash
pnpm install
# or npm install / yarn install
```

### 3. Run Locally

```bash
pnpm dev
```

Open `http://localhost:5173` in your browser.

### 4. Build for Production

```bash
pnpm build
```

This generates a production-ready build in the `dist/` directory.

## Deployment Options

### Option A: Vercel (Recommended for Static)

1. Push your code to GitHub
2. Connect your repository to [Vercel](https://vercel.com)
3. Vercel auto-detects the Vite configuration and deploys automatically
4. Your site will be live at `your-project.vercel.app`

### Option B: Netlify

1. Push your code to GitHub
2. Connect your repository to [Netlify](https://netlify.com)
3. Set build command: `pnpm build`
4. Set publish directory: `dist`
5. Deploy

### Option C: GitHub Pages

1. Update `vite.config.ts` to set the correct `base`:
   ```typescript
   export default defineConfig({
     base: '/analog-athlete/', // if deploying to a subdirectory
   });
   ```

2. Push to GitHub and enable GitHub Pages in repository settings
3. Select the `gh-pages` branch as the source

### Option D: Self-Hosted (Node.js)

1. Build the project:
   ```bash
   pnpm build
   ```

2. Install production dependencies:
   ```bash
   pnpm install --prod
   ```

3. Start the server:
   ```bash
   node dist/index.js
   ```

4. The app will be available at `http://localhost:3000`

## Environment Variables

This is a static frontend with no backend API calls. No environment variables are required for basic functionality.

If you plan to add backend features later, create a `.env.local` file:

```env
VITE_API_URL=https://your-api.com
```

## Project Structure

```
analog-athlete/
├── client/
│   ├── index.html          # Entry HTML
│   ├── src/
│   │   ├── App.tsx         # Main router
│   │   ├── index.css       # Global styles (Neo-Retro theme)
│   │   ├── main.tsx        # React entry point
│   │   ├── pages/          # Page components
│   │   ├── components/     # Reusable UI components
│   │   ├── contexts/       # React contexts
│   │   ├── hooks/          # Custom hooks
│   │   └── lib/            # Utilities
│   └── public/             # Static assets
├── server/                 # Express server (for production)
├── shared/                 # Shared types
├── package.json
├── vite.config.ts
├── tsconfig.json
└── README.md
```

## Customization

### Update Branding

- **Logo**: Replace the "AA" stamp in `client/src/pages/Home.tsx`
- **Colors**: Edit CSS variables in `client/src/index.css` (OKLCH format)
- **Typography**: Modify font imports in `client/index.html`

### Add New Pages

1. Create a new file in `client/src/pages/`
2. Add a route in `client/src/App.tsx`

Example:

```tsx
// client/src/pages/Sessions.tsx
export default function Sessions() {
  return <div>Sessions Page</div>;
}

// client/src/App.tsx
import Sessions from "./pages/Sessions";

function Router() {
  return (
    <Switch>
      <Route path="/" component={Home} />
      <Route path="/sessions" component={Sessions} />
      {/* ... */}
    </Switch>
  );
}
```

## Performance

- **CSS**: Tailwind 4 with optimized purging
- **Images**: All hero images are CDN-hosted (no local bloat)
- **Bundle**: ~575 KB minified (167 KB gzipped)

## Browser Support

- Chrome/Edge 90+
- Firefox 88+
- Safari 14+
- Mobile browsers (iOS Safari 14+, Chrome Mobile)

## Troubleshooting

### Build fails with missing dependencies

```bash
pnpm install
pnpm build
```

### Port 3000 already in use

```bash
PORT=3001 pnpm dev
```

### Images not loading

Ensure the CDN URLs in `client/src/pages/Home.tsx` are accessible. If deploying behind a firewall, download images locally and update references.

## Support

For issues or questions about the design system, refer to:
- `ideas.md` – Design philosophy and Neo-Retro principles
- `client/src/index.css` – Global theme and component tokens
- `client/src/pages/Home.tsx` – Component usage examples

---

**Analog Athlete** – Designed for disciplined momentum. Built for the web.
